package Classes;

public class Dagger extends Weapon{


    public Dagger(){
        this.setAttackModifier(5);
        this.setWeight(0);
        this.setName("Dagger");
        this.setDescription("Fast and effective.");
    }
}
