package Classes;

public class Sword extends Weapon{


    public Sword(){
        this.setAttackModifier(5);
        this.setWeight(10);
        this.setName("Sword");
        this.setDescription("Middle of the line.");
    }
}
