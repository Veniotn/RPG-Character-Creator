package Classes;

abstract class Asset {
    protected String name;

    public Asset(String name){
        this.setName(name);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
