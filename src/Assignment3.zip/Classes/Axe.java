package Classes;

public class Axe extends Weapon{


    public Axe(){
        super();
        this.setAttackModifier(10);
        this.setWeight(15);
        this.setName("Axe");
        this.setDescription("Heavy but packs a punch.");
    }
}
